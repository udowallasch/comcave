#pragma once
class aufgabe2 {
public:
	aufgabe2();
	~aufgabe2();
	void run();
};

