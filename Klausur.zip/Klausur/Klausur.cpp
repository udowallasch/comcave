
#include "pch.h"
#include <iostream>
#include "aufgabe4.h"


using namespace std;

int main()
{
	aufgabe4 a4;
	a4.run();

}
