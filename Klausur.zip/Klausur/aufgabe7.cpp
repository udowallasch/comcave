#include "pch.h"
#include "aufgabe7.h"
#include<iostream>
#include<sstream>


using namespace std;

namespace {





}

void aufgabe7::run() {
	cout << "aufgabe 7 ----------------------------------------" << endl;



}


aufgabe7::aufgabe7() {}
aufgabe7::~aufgabe7() {}
