#include "pch.h"
#include<iostream>
#include<sstream>
#include "aufgabe2.h"

using namespace std;

namespace {





}

void aufgabe2::run() {
	cout << "aufgabe 2 ----------------------------------------" << endl;


}


aufgabe2::aufgabe2() {}
aufgabe2::~aufgabe2() {}
