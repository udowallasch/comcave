#pragma once

class aufgabe6 {
public:
	void run();
	aufgabe6();
	~aufgabe6();
};

