#pragma once
class aufgabe4 {
public:
	aufgabe4();
	~aufgabe4();
	void run();
};

