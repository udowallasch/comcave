#pragma once
class aufgabe8 {
public:
	void run();
	aufgabe8();
	~aufgabe8();
};

