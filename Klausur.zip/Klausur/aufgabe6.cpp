#include "pch.h"
#include "aufgabe6.h"

#include<iostream>
#include<sstream>


using namespace std;

namespace {





}

void aufgabe6::run() {
	cout << "aufgabe 6 ----------------------------------------" << endl;



}


aufgabe6::aufgabe6() {}
aufgabe6::~aufgabe6() {}
