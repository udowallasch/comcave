#include "pch.h"
#include "aufgabe8.h"
#include<iostream>
#include<sstream>


using namespace std;

namespace {





}

void aufgabe8::run() {
	cout << "aufgabe 8 ----------------------------------------" << endl;



}


aufgabe8::aufgabe8() {}
aufgabe8::~aufgabe8() {}
