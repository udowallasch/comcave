#pragma once
class test {
public:
	test();
	~test();
	void run();
};

