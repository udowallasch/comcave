#include "pch.h"
#include<iostream>
#include<sstream>
#include "aufgabe3.h"

using namespace std;

namespace {





}

void aufgabe3::run() {
	cout << "aufgabe 3 ----------------------------------------" << endl;


}


aufgabe3::aufgabe3() {}
aufgabe3::~aufgabe3() {}
