#pragma once
class aufgabe1 {
public:
	aufgabe1();
	~aufgabe1();
	void run();
};

