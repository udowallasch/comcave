#pragma once
class aufgabe3 {
public:
	aufgabe3();
	~aufgabe3();
	void run();
};

