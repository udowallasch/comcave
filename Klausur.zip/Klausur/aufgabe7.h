#pragma once
class aufgabe7 {
public:
	void run();
	aufgabe7();
	~aufgabe7();
};

