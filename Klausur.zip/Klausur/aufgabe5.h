#pragma once
class aufgabe5 {
public:
	aufgabe5();
	~aufgabe5();
	void run();
};

