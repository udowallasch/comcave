#include "pch.h"
#include<iostream>
#include<sstream>
#include "aufgabe5.h"


using namespace std;

namespace {





}

void aufgabe5::run() {
	cout << "aufgabe 5 ----------------------------------------" << endl;



}

aufgabe5::aufgabe5() {}
aufgabe5::~aufgabe5() {}
